-- Profile.lua - agent write channel (fixed name, always listed in the TOC)
-- shipped blank: settings live in SavedVariables, not here
AzerothKitProfile = {
    version = 1,
    modules = {
    },
}